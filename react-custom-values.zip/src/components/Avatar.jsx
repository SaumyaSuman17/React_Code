import React from "react";

function Avatar(props) {
  return <img className="circle_img" src={props.img} alt="flower" />;
}

export default Avatar;
