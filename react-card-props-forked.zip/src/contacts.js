const Contacts = [
  {
    name: "Saumya Suman",
    pic:
      "https://media-exp1.licdn.com/dms/image/C5103AQHUjpVkhkn9-g/profile-displayphoto-shrink_200_200/0/1574777231656?e=1634169600&v=beta&t=ZMZqfqO7hLlJShDRALbPGCYw2yu1m5rwpXXQnQCXHxA",
    Ph_no: "7063185213",
    email_id: "saumya.suman1702@gmail.com"
  },
  {
    name: "Samy",
    pic:
      "https://media-exp1.licdn.com/dms/image/C5103AQHUjpVkhkn9-g/profile-displayphoto-shrink_200_200/0/1574777231656?e=1634169600&v=beta&t=ZMZqfqO7hLlJShDRALbPGCYw2yu1m5rwpXXQnQCXHxA",
    Ph_no: "7069985213",
    email_id: "saumya.suman17@gmail.com"
  },
  {
    name: "Sam",
    pic:
      "https://media-exp1.licdn.com/dms/image/C5103AQHUjpVkhkn9-g/profile-displayphoto-shrink_200_200/0/1574777231656?e=1634169600&v=beta&t=ZMZqfqO7hLlJShDRALbPGCYw2yu1m5rwpXXQnQCXHxA",
    Ph_no: "7068765213",
    email_id: "saumya.sumi17@gmail.com"
  }
];
export default Contacts;
