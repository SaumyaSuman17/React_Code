import React from "react";

function Card(props) {
  return (
    <div className="Card">
      <div className="top">
        <h2 className="name">{props.name}</h2>
        <img className="circle_img" src={props.pic} alt="pic_1" />
      </div>
      <div className="bottom">
        <p className="info">{props.ph_no}</p>
        <p className="info">{props.email_id}</p>
      </div>
    </div>
  );
}
export default Card;
