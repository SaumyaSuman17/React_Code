import React from "react";
import Card from "./Card";
import contacts from "../contacts";
function App() {
  return (
    <div>
      <Card
        name={contacts[0].name}
        pic={contacts[0].pic}
        ph_no={contacts[0].Ph_no}
        email_id={contacts[0].email_id}
      />
      <Card
        name={contacts[1].name}
        pic={contacts[1].pic}
        ph_no={contacts[1].Ph_no}
        email_id={contacts[1].email_id}
      />
      <Card
        name={contacts[2].name}
        pic={contacts[2].pic}
        ph_no={contacts[2].Ph_no}
        email_id={contacts[2].email_id}
      />
    </div>
  );
}
export default App;
