import React from "react";
import ReactDOM from "react-dom";
import App from "./components/App";

ReactDOM.render(
  <div>
    <h1>My Contacts</h1>
    <App />
  </div>,
  document.getElementById("root")
);
